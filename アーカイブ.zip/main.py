from dotenv import load_dotenv
import os
from google.cloud import firestore
from datetime import datetime

# .env ファイルから環境変数を読み込む
load_dotenv()

# サービスアカウントキーのパスを環境変数から取得
service_account_key_path = os.environ.get('SERVICE_ACCOUNT_KEY_PATH')

# Firestoreクライアントの初期化
db = firestore.Client.from_service_account_json(service_account_key_path)

def delete_expired_events(request):
    try:
        current_time = datetime.utcnow()

        # イベントコレクションの参照
        events_ref = db.collection('Event')
        Attend_ref = db.collection("AttendList")
        event_doc_ids = []

        # 現在時刻を超えているイベントを取得
        
        expired_events_query = events_ref.where('endTime', '<', current_time)
        expired_events = expired_events_query.stream()

        for event in expired_events:
            event_doc_ids.append(event.id)
            event.reference.delete()
            
        for attend_doc in Attend_ref.stream():
            # AttendListのドキュメントが関連するEventが存在する場合のみ削除
            if attend_doc.id in event_doc_ids:
                attend_doc.reference.delete()
 
        
    
    except Exception as e:
        return f"Error: {e}"

# ローカルでのテスト用
if __name__ == "__main__":
    # ローカルでのテスト
    delete_expired_events(None)
    print("削除した")
